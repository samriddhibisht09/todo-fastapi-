const API_BASE_URL = "http://127.0.0.1:8000";

const authCard = document.getElementById("authCard");
const dashboard = document.getElementById("dashboard");
const authMessage = document.getElementById("authMessage");
const todoMessage = document.getElementById("todoMessage");

function showForm(formName) {
  document.getElementById("loginForm").classList.add("hidden");
  document.getElementById("signupForm").classList.add("hidden");
  document.getElementById("forgotForm").classList.add("hidden");

  document.querySelectorAll(".tab").forEach(tab => tab.classList.remove("active"));

  if (formName === "login") {
    document.getElementById("loginForm").classList.remove("hidden");
    document.querySelectorAll(".tab")[0].classList.add("active");
  }

  if (formName === "signup") {
    document.getElementById("signupForm").classList.remove("hidden");
    document.querySelectorAll(".tab")[1].classList.add("active");
  }

  if (formName === "forgot") {
    document.getElementById("forgotForm").classList.remove("hidden");
  }

  authMessage.textContent = "";
}

function getToken() {
  return localStorage.getItem("access_token");
}

function setToken(token) {
  localStorage.setItem("access_token", token);
}

function logout() {
  localStorage.removeItem("access_token");
  authCard.classList.remove("hidden");
  dashboard.classList.add("hidden");
}

async function apiRequest(path, method = "GET", body = null, useAuth = true) {
  const headers = {
    "Content-Type": "application/json"
  };

  if (useAuth && getToken()) {
    headers["Authorization"] = `Bearer ${getToken()}`;
  }

  const response = await fetch(`${API_BASE_URL}${path}`, {
    method,
    headers,
    body: body ? JSON.stringify(body) : null
  });

  const data = await response.json();

  if (!response.ok) {
    throw new Error(data.detail || data.message || "Something went wrong");
  }

  return data;
}

document.getElementById("signupForm").addEventListener("submit", async (e) => {
  e.preventDefault();

  const email = document.getElementById("signupEmail").value;
  const phone_number = document.getElementById("signupPhone").value;
  const password = document.getElementById("signupPassword").value;

  try {
    await apiRequest("/signup", "POST", { email, phone_number, password }, false);
    authMessage.textContent = "Account created. Please login.";
    showForm("login");
  } catch (error) {
    authMessage.textContent = error.message;
  }
});

document.getElementById("loginForm").addEventListener("submit", async (e) => {
  e.preventDefault();

  const email = document.getElementById("loginEmail").value;
  const password = document.getElementById("loginPassword").value;

  try {
    const data = await apiRequest("/login", "POST", { email, password }, false);

    // Expected backend response:
    // { "access_token": "token_here", "token_type": "bearer" }
    setToken(data.access_token);

    authCard.classList.add("hidden");
    dashboard.classList.remove("hidden");
    loadTodos();
  } catch (error) {
    authMessage.textContent = error.message;
  }
});

document.getElementById("forgotForm").addEventListener("submit", async (e) => {
  e.preventDefault();

  const email = document.getElementById("forgotEmail").value;

  try {
    await apiRequest("/forgot-password", "POST", { email }, false);
    authMessage.textContent = "If this email exists, reset instructions will be sent.";
  } catch (error) {
    authMessage.textContent = error.message;
  }
});

document.getElementById("todoForm").addEventListener("submit", async (e) => {
  e.preventDefault();

  const task = document.getElementById("todoInput").value;

  try {
    await apiRequest("/todos", "POST", { task });
    document.getElementById("todoInput").value = "";
    loadTodos();
  } catch (error) {
    todoMessage.textContent = error.message;
  }
});

async function loadTodos() {
  try {
    const todos = await apiRequest("/todos");
    renderTodos(todos);
  } catch (error) {
    todoMessage.textContent = error.message;
  }
}

function renderTodos(todos) {
  const todosList = document.getElementById("todosList");
  todosList.innerHTML = "";

  if (!todos.length) {
    todosList.innerHTML = "<p>No todos yet.</p>";
    return;
  }

  todos.forEach(todo => {
    const div = document.createElement("div");
    div.className = "todo-item";

    div.innerHTML = `
      <div class="todo-left">
        <input type="checkbox" ${todo.completed ? "checked" : ""} onchange="toggleTodo(${todo.id}, '${escapeQuotes(todo.task)}', this.checked)" />
        <span class="${todo.completed ? "completed" : ""}">${todo.task}</span>
      </div>
      <div class="todo-actions">
        <button class="small-btn" onclick="editTodo(${todo.id}, '${escapeQuotes(todo.task)}', ${todo.completed})">Edit</button>
        <button class="small-btn delete-btn" onclick="deleteTodo(${todo.id})">Delete</button>
      </div>
    `;

    todosList.appendChild(div);
  });
}

function escapeQuotes(text) {
  return text.replace(/'/g, "\'");
}

async function toggleTodo(id, task, completed) {
  try {
    await apiRequest(`/todos/${id}`, "PUT", { task, completed });
    loadTodos();
  } catch (error) {
    todoMessage.textContent = error.message;
  }
}

async function editTodo(id, oldTask, completed) {
  const newTask = prompt("Edit todo:", oldTask);

  if (!newTask) return;

  try {
    await apiRequest(`/todos/${id}`, "PUT", { task: newTask, completed });
    loadTodos();
  } catch (error) {
    todoMessage.textContent = error.message;
  }
}

async function deleteTodo(id) {
  try {
    await apiRequest(`/todos/${id}`, "DELETE");
    loadTodos();
  } catch (error) {
    todoMessage.textContent = error.message;
  }
}

if (getToken()) {
  authCard.classList.add("hidden");
  dashboard.classList.remove("hidden");
  loadTodos();
}
