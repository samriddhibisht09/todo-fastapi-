# Todo Frontend

This is a simple frontend for your FastAPI Todo app.

## Files

- `index.html` - page structure
- `styles.css` - design
- `app.js` - frontend logic and API calls

## How to run

Open `index.html` in your browser.

## Backend endpoints expected

This frontend expects your FastAPI backend to have:

- `POST /signup`
- `POST /login`
- `POST /forgot-password`
- `GET /todos`
- `POST /todos`
- `PUT /todos/{todo_id}`
- `DELETE /todos/{todo_id}`

The login endpoint should return:

```json
{
  "access_token": "your_token",
  "token_type": "bearer"
}
```

Authenticated todo routes should accept:

```http
Authorization: Bearer your_token
```
